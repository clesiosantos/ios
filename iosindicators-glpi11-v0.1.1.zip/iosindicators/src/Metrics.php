<?php

namespace GlpiPlugin\Iosindicators;

use DateTimeImmutable;
use DateTimeInterface;
use Throwable;
use Ticket;

final class Metrics
{
    /**
     * Consolida os indicadores de ciclo de vida do incidente.
     * O período é aplicado à data de abertura do ticket (glpi_tickets.date).
     *
     * A v0.1.1 é tolerante a diferenças de schema: métricas opcionais são
     * calculadas apenas quando os campos/tabelas existem e erros de consulta
     * são devolvidos em diagnostics, em vez de derrubar toda a página.
     */
    public static function summary(DateTimeInterface $from, DateTimeInterface $to): array
    {
        global $DB;

        $diagnostics = [];
        $defaults = self::emptySummary();

        if (!$DB->tableExists('glpi_tickets')) {
            $diagnostics[] = 'Tabela glpi_tickets não encontrada.';
            $defaults['diagnostics'] = $diagnostics;
            return $defaults;
        }

        $fromSql  = $DB->escape($from->format('Y-m-d H:i:s'));
        $toSql    = $DB->escape($to->format('Y-m-d H:i:s'));
        $entities = self::entitySql();
        $typeFilter = ((int)Settings::get('show_only_incidents', 1) === 1)
            ? ' AND t.`type` = ' . (int)Ticket::INCIDENT_TYPE
            : '';

        // Todos estes campos existem no GLPI 11 padrão, mas validamos antes para
        // impedir uma falha total caso o banco tenha vindo de uma migração incompleta.
        $select = [
            'COUNT(*) AS total',
            'SUM(CASE WHEN t.`status` = ' . (int)Ticket::INCOMING . ' THEN 1 ELSE 0 END) AS incoming',
            'SUM(CASE WHEN t.`status` = ' . (int)Ticket::ASSIGNED . ' THEN 1 ELSE 0 END) AS assigned',
            'SUM(CASE WHEN t.`status` = ' . (int)Ticket::PLANNED . ' THEN 1 ELSE 0 END) AS planned',
            'SUM(CASE WHEN t.`status` = ' . (int)Ticket::WAITING . ' THEN 1 ELSE 0 END) AS pending',
            'SUM(CASE WHEN t.`status` = ' . (int)Ticket::SOLVED . ' THEN 1 ELSE 0 END) AS solved',
            'SUM(CASE WHEN t.`status` = ' . (int)Ticket::CLOSED . ' THEN 1 ELSE 0 END) AS closed',
            'SUM(CASE WHEN t.`status` NOT IN (' . (int)Ticket::SOLVED . ', ' . (int)Ticket::CLOSED . ') THEN 1 ELSE 0 END) AS open_count',
        ];

        $optional = [
            'takeintoaccount_delay_stat' => 'AVG(NULLIF(t.`takeintoaccount_delay_stat`, 0)) AS avg_tto',
            'solve_delay_stat'           => 'AVG(CASE WHEN t.`solvedate` IS NOT NULL AND t.`solve_delay_stat` > 0 THEN t.`solve_delay_stat` END) AS avg_tts',
            'actiontime'                 => 'AVG(CASE WHEN t.`solvedate` IS NOT NULL AND t.`actiontime` > 0 THEN t.`actiontime` END) AS avg_tma',
            'waiting_duration'           => 'AVG(NULLIF(t.`waiting_duration`, 0)) AS avg_waiting',
            'close_delay_stat'           => 'AVG(NULLIF(t.`close_delay_stat`, 0)) AS avg_close_delay',
        ];

        foreach ($optional as $field => $expression) {
            if ($DB->fieldExists('glpi_tickets', $field)) {
                $select[] = $expression;
            } else {
                $diagnostics[] = "Campo glpi_tickets.{$field} não encontrado; indicador correspondente ficará sem valor.";
            }
        }

        if ($DB->fieldExists('glpi_tickets', 'solve_delay_stat')) {
            $select[] = 'AVG(CASE WHEN t.`solvedate` IS NOT NULL AND t.`solve_delay_stat` > 0 THEN t.`solve_delay_stat` END) AS avg_mttr';
            $select[] = 'AVG(NULLIF(t.`solve_delay_stat`, 0)) AS avg_solve_delay';
        }
        if ($DB->fieldExists('glpi_tickets', 'actiontime')) {
            $select[] = 'AVG(NULLIF(t.`actiontime`, 0)) AS avg_actiontime';
        }

        // Tempo total do incidente: abertura até fechamento; se ainda não fechou, usa solução.
        if ($DB->fieldExists('glpi_tickets', 'closedate') && $DB->fieldExists('glpi_tickets', 'solvedate')) {
            $select[] = 'AVG(CASE WHEN COALESCE(t.`closedate`, t.`solvedate`) IS NOT NULL '
                . 'THEN TIMESTAMPDIFF(SECOND, t.`date`, COALESCE(t.`closedate`, t.`solvedate`)) END) AS avg_total_incident';
        }

        $sql = "SELECT\n                " . implode(",\n                ", $select) . "\n"
            . "FROM `glpi_tickets` t\n"
            . "WHERE t.`is_deleted` = 0\n"
            . $typeFilter . "\n"
            . "  AND t.`entities_id` IN ({$entities})\n"
            . "  AND t.`date` >= '{$fromSql}'\n"
            . "  AND t.`date` <= '{$toSql}'";

        $row = self::safeQueryOne($sql, 'Consulta principal de indicadores', $diagnostics);

        $base = array_merge($defaults, [
            'total'              => (int)($row['total'] ?? 0),
            'incoming'           => (int)($row['incoming'] ?? 0),
            'assigned'           => (int)($row['assigned'] ?? 0),
            'planned'            => (int)($row['planned'] ?? 0),
            'pending'            => (int)($row['pending'] ?? 0),
            'solved'             => (int)($row['solved'] ?? 0),
            'closed'             => (int)($row['closed'] ?? 0),
            'open'               => (int)($row['open_count'] ?? 0),
            'avg_tto'            => self::floatOrNull($row['avg_tto'] ?? null),
            'avg_tts'            => self::floatOrNull($row['avg_tts'] ?? null),
            'avg_tma'            => self::floatOrNull($row['avg_tma'] ?? null),
            'avg_mttr'           => self::floatOrNull($row['avg_mttr'] ?? null),
            'avg_total_incident' => self::floatOrNull($row['avg_total_incident'] ?? null),
            'avg_waiting'        => self::floatOrNull($row['avg_waiting'] ?? null),
        ]);

        $taskMetrics = self::taskMetrics($from, $to, $diagnostics);
        $base = array_merge($base, $taskMetrics);

        $base['mbtr'] = self::resolveMbtr($row);
        $base['period_from'] = $from->format('Y-m-d H:i:s');
        $base['period_to']   = $to->format('Y-m-d H:i:s');
        $base['diagnostics'] = $diagnostics;

        return $base;
    }

    private static function emptySummary(): array
    {
        return [
            'total' => 0,
            'incoming' => 0,
            'assigned' => 0,
            'planned' => 0,
            'pending' => 0,
            'solved' => 0,
            'closed' => 0,
            'open' => 0,
            'avg_tto' => null,
            'avg_tts' => null,
            'avg_tma' => null,
            'avg_mttr' => null,
            'avg_total_incident' => null,
            'avg_waiting' => null,
            'mbtr' => null,
            'ai_tagged' => 0,
            'rca_complete' => 0,
            'remote_tasks' => 0,
            'rca_coverage_pct' => 0.0,
            'rca_complete_pct' => 0.0,
            'resolved_for_rca_den' => 0,
            'period_from' => null,
            'period_to' => null,
            'diagnostics' => [],
        ];
    }

    /**
     * Indicadores construídos a partir das tarefas do ticket.
     */
    private static function taskMetrics(DateTimeInterface $from, DateTimeInterface $to, array &$diagnostics): array
    {
        global $DB;

        $empty = [
            'ai_tagged' => 0,
            'rca_complete' => 0,
            'remote_tasks' => 0,
            'rca_coverage_pct' => 0.0,
            'rca_complete_pct' => 0.0,
            'resolved_for_rca_den' => 0,
        ];

        if (!$DB->tableExists('glpi_tickettasks')) {
            $diagnostics[] = 'Tabela glpi_tickettasks não encontrada; indicadores de RCA foram desativados.';
            return $empty;
        }
        foreach (['tickets_id', 'content'] as $field) {
            if (!$DB->fieldExists('glpi_tickettasks', $field)) {
                $diagnostics[] = "Campo glpi_tickettasks.{$field} não encontrado; indicadores de RCA foram desativados.";
                return $empty;
            }
        }

        $fromSql  = $DB->escape($from->format('Y-m-d H:i:s'));
        $toSql    = $DB->escape($to->format('Y-m-d H:i:s'));
        $entities = self::entitySql();
        $aiTag = self::escapeLike((string)Settings::get('ai_task_tag', '[IA-RCA]'));
        $remoteTag = self::escapeLike((string)Settings::get('remote_task_tag', '[REMOTO]'));
        $typeFilter = ((int)Settings::get('show_only_incidents', 1) === 1)
            ? ' AND t.`type` = ' . (int)Ticket::INCIDENT_TYPE
            : '';

        $sql = "
            SELECT
                COUNT(DISTINCT CASE WHEN tt.`content` LIKE '%{$aiTag}%' ESCAPE '\\\\' THEN t.`id` END) AS tagged_tickets,
                COUNT(DISTINCT CASE
                    WHEN tt.`content` LIKE '%{$aiTag}%' ESCAPE '\\\\'
                     AND LOWER(tt.`content`) LIKE '%diagn%stico%'
                     AND LOWER(tt.`content`) LIKE '%causa%'
                     AND LOWER(tt.`content`) LIKE '%solu%'
                    THEN t.`id` END) AS rca_complete,
                COUNT(CASE WHEN tt.`content` LIKE '%{$remoteTag}%' ESCAPE '\\\\' THEN 1 END) AS remote_tasks
            FROM `glpi_tickets` t
            LEFT JOIN `glpi_tickettasks` tt ON tt.`tickets_id` = t.`id`
            WHERE t.`is_deleted` = 0
              {$typeFilter}
              AND t.`entities_id` IN ({$entities})
              AND t.`date` >= '{$fromSql}'
              AND t.`date` <= '{$toSql}'
        ";

        $row = self::safeQueryOne($sql, 'Consulta de tarefas/RCA', $diagnostics);
        $resolved = self::resolvedCount($from, $to, $diagnostics);
        $tagged = (int)($row['tagged_tickets'] ?? 0);
        $complete = (int)($row['rca_complete'] ?? 0);

        return [
            'ai_tagged'            => $tagged,
            'rca_complete'         => $complete,
            'remote_tasks'         => (int)($row['remote_tasks'] ?? 0),
            'rca_coverage_pct'     => $resolved > 0 ? round(($tagged / $resolved) * 100, 1) : 0.0,
            'rca_complete_pct'     => $resolved > 0 ? round(($complete / $resolved) * 100, 1) : 0.0,
            'resolved_for_rca_den' => $resolved,
        ];
    }

    private static function resolvedCount(DateTimeInterface $from, DateTimeInterface $to, array &$diagnostics): int
    {
        global $DB;

        $fromSql  = $DB->escape($from->format('Y-m-d H:i:s'));
        $toSql    = $DB->escape($to->format('Y-m-d H:i:s'));
        $entities = self::entitySql();
        $typeFilter = ((int)Settings::get('show_only_incidents', 1) === 1)
            ? ' AND t.`type` = ' . (int)Ticket::INCIDENT_TYPE
            : '';

        $sql = "
            SELECT COUNT(*) AS total
            FROM `glpi_tickets` t
            WHERE t.`is_deleted` = 0
              {$typeFilter}
              AND t.`entities_id` IN ({$entities})
              AND t.`date` >= '{$fromSql}'
              AND t.`date` <= '{$toSql}'
              AND t.`status` IN (" . (int)Ticket::SOLVED . ', ' . (int)Ticket::CLOSED . ")
        ";

        $row = self::safeQueryOne($sql, 'Contagem de tickets resolvidos', $diagnostics);
        return (int)($row['total'] ?? 0);
    }

    private static function safeQueryOne(string $sql, string $label, array &$diagnostics): array
    {
        global $DB;

        try {
            $result = $DB->query($sql);
            if (!$result) {
                $diagnostics[] = $label . ': consulta não retornou resultado.';
                return [];
            }
            $row = $DB->fetchAssoc($result);
            return is_array($row) ? $row : [];
        } catch (Throwable $e) {
            $diagnostics[] = $label . ': ' . $e->getMessage();
            return [];
        }
    }

    private static function escapeLike(string $value): string
    {
        global $DB;
        $value = str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $value);
        return $DB->escape($value);
    }

    private static function resolveMbtr(array $row): ?float
    {
        $source = (string)Settings::get('mbtr_source', 'none');
        $map = [
            'waiting_duration' => 'avg_waiting',
            'close_delay_stat' => 'avg_close_delay',
            'actiontime'       => 'avg_actiontime',
            'solve_delay_stat' => 'avg_solve_delay',
        ];

        if (!isset($map[$source])) {
            return null;
        }

        return self::floatOrNull($row[$map[$source]] ?? null);
    }

    public static function periodFromRequest(array $request): array
    {
        $defaultDays = max(1, (int)Settings::get('default_period_days', 30));
        $days = isset($request['days']) ? max(1, min(3650, (int)$request['days'])) : $defaultDays;

        $to = new DateTimeImmutable('now');
        $from = $to->modify('-' . ($days - 1) . ' days')->setTime(0, 0, 0);

        if (!empty($request['from']) && !empty($request['to'])) {
            $customFrom = DateTimeImmutable::createFromFormat('Y-m-d H:i:s', $request['from'] . ' 00:00:00');
            $customTo   = DateTimeImmutable::createFromFormat('Y-m-d H:i:s', $request['to'] . ' 23:59:59');
            if ($customFrom && $customTo && $customFrom <= $customTo) {
                $from = $customFrom;
                $to   = $customTo;
            }
        }

        return [$from, $to];
    }

    public static function duration(?float $seconds): string
    {
        if ($seconds === null) {
            return '—';
        }

        $seconds = max(0, (int)round($seconds));
        $days = intdiv($seconds, 86400);
        $hours = intdiv($seconds % 86400, 3600);
        $minutes = intdiv($seconds % 3600, 60);
        $secs = $seconds % 60;

        if ($days > 0) {
            return sprintf('%dd %02dh %02dm', $days, $hours, $minutes);
        }
        if ($hours > 0) {
            return sprintf('%dh %02dm', $hours, $minutes);
        }
        if ($minutes > 0) {
            return sprintf('%dm %02ds', $minutes, $secs);
        }
        return sprintf('%ds', $secs);
    }

    private static function entitySql(): string
    {
        $ids = $_SESSION['glpiactiveentities'] ?? [($_SESSION['glpiactive_entity'] ?? 0)];
        if (!is_array($ids) || $ids === []) {
            $ids = [0];
        }

        // Em GLPI os valores da matriz são os próprios IDs; array_values evita
        // problemas caso o array seja associativo.
        $ids = array_values(array_unique(array_map('intval', $ids)));
        if ($ids === []) {
            $ids = [0];
        }
        return implode(',', $ids);
    }

    private static function floatOrNull(mixed $value): ?float
    {
        if ($value === null || $value === '') {
            return null;
        }
        return (float)$value;
    }
}
