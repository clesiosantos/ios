<?php

namespace GlpiPlugin\Iosindicators;

use DateTimeImmutable;
use DateTimeInterface;
use Ticket;

final class Metrics
{
    /**
     * Consolida os indicadores de ciclo de vida do incidente.
     * O período é aplicado à data de abertura do ticket (glpi_tickets.date).
     */
    public static function summary(DateTimeInterface $from, DateTimeInterface $to): array
    {
        global $DB;

        $fromSql = $DB->escape($from->format('Y-m-d H:i:s'));
        $toSql   = $DB->escape($to->format('Y-m-d H:i:s'));
        $entities = self::entitySql();
        $typeFilter = ((int)Settings::get('show_only_incidents', 1) === 1)
            ? ' AND t.`type` = ' . (int)Ticket::INCIDENT_TYPE
            : '';

        $sql = "
            SELECT
                COUNT(*) AS total,
                SUM(CASE WHEN t.status = " . (int)Ticket::INCOMING . " THEN 1 ELSE 0 END) AS incoming,
                SUM(CASE WHEN t.status = " . (int)Ticket::ASSIGNED . " THEN 1 ELSE 0 END) AS assigned,
                SUM(CASE WHEN t.status = " . (int)Ticket::PLANNED . " THEN 1 ELSE 0 END) AS planned,
                SUM(CASE WHEN t.status = " . (int)Ticket::WAITING . " THEN 1 ELSE 0 END) AS pending,
                SUM(CASE WHEN t.status = " . (int)Ticket::SOLVED . " THEN 1 ELSE 0 END) AS solved,
                SUM(CASE WHEN t.status = " . (int)Ticket::CLOSED . " THEN 1 ELSE 0 END) AS closed,
                SUM(CASE WHEN t.status NOT IN (" . (int)Ticket::SOLVED . ", " . (int)Ticket::CLOSED . ") THEN 1 ELSE 0 END) AS open_count,
                AVG(NULLIF(t.takeintoaccount_delay_stat, 0)) AS avg_tto,
                AVG(CASE WHEN t.solvedate IS NOT NULL AND t.solve_delay_stat > 0 THEN t.solve_delay_stat END) AS avg_tts,
                AVG(CASE WHEN t.solvedate IS NOT NULL AND t.actiontime > 0 THEN t.actiontime END) AS avg_tma,
                AVG(CASE WHEN t.solvedate IS NOT NULL AND t.solve_delay_stat > 0 THEN t.solve_delay_stat END) AS avg_mttr,
                AVG(NULLIF(t.waiting_duration, 0)) AS avg_waiting,
                AVG(NULLIF(t.close_delay_stat, 0)) AS avg_close_delay,
                AVG(NULLIF(t.actiontime, 0)) AS avg_actiontime,
                AVG(NULLIF(t.solve_delay_stat, 0)) AS avg_solve_delay
            FROM glpi_tickets t
            WHERE t.is_deleted = 0
              {$typeFilter}
              AND t.entities_id IN ({$entities})
              AND t.date >= '{$fromSql}'
              AND t.date <= '{$toSql}'
        ";

        $result = $DB->query($sql);
        $row = $result ? $DB->fetchAssoc($result) : [];

        $base = [
            'total'       => (int)($row['total'] ?? 0),
            'incoming'    => (int)($row['incoming'] ?? 0),
            'assigned'    => (int)($row['assigned'] ?? 0),
            'planned'     => (int)($row['planned'] ?? 0),
            'pending'     => (int)($row['pending'] ?? 0),
            'solved'      => (int)($row['solved'] ?? 0),
            'closed'      => (int)($row['closed'] ?? 0),
            'open'        => (int)($row['open_count'] ?? 0),
            'avg_tto'     => self::floatOrNull($row['avg_tto'] ?? null),
            'avg_tts'     => self::floatOrNull($row['avg_tts'] ?? null),
            'avg_tma'     => self::floatOrNull($row['avg_tma'] ?? null),
            'avg_mttr'          => self::floatOrNull($row['avg_mttr'] ?? null),
            'avg_total_incident' => self::floatOrNull($row['avg_total_incident'] ?? null),
            'avg_waiting'        => self::floatOrNull($row['avg_waiting'] ?? null),
        ];

        $taskMetrics = self::taskMetrics($from, $to);
        $base = array_merge($base, $taskMetrics);

        $base['mbtr'] = self::resolveMbtr($row);
        $base['period_from'] = $from->format('Y-m-d H:i:s');
        $base['period_to']   = $to->format('Y-m-d H:i:s');

        return $base;
    }

    /**
     * Indicadores construídos a partir das tarefas do ticket, conforme o padrão acordado para IA/RCA.
     */
    private static function taskMetrics(DateTimeInterface $from, DateTimeInterface $to): array
    {
        global $DB;

        $fromSql = $DB->escape($from->format('Y-m-d H:i:s'));
        $toSql   = $DB->escape($to->format('Y-m-d H:i:s'));
        $entities = self::entitySql();
        $aiTag = $DB->escape((string)Settings::get('ai_task_tag', '[IA-RCA]'));
        $remoteTag = $DB->escape((string)Settings::get('remote_task_tag', '[REMOTO]'));
        $typeFilter = ((int)Settings::get('show_only_incidents', 1) === 1)
            ? ' AND t.`type` = ' . (int)Ticket::INCIDENT_TYPE
            : '';

        // Para RCA completa, exigimos a tarefa marcada e os três blocos mínimos: diagnóstico, causa e solução.
        $sql = "
            SELECT
                COUNT(DISTINCT CASE WHEN tt.content LIKE '%{$aiTag}%' THEN t.id END) AS tagged_tickets,
                COUNT(DISTINCT CASE
                    WHEN tt.content LIKE '%{$aiTag}%'
                     AND LOWER(tt.content) LIKE '%diagn%stico%'
                     AND LOWER(tt.content) LIKE '%causa%'
                     AND LOWER(tt.content) LIKE '%solu%'
                    THEN t.id END) AS rca_complete,
                COUNT(CASE WHEN tt.content LIKE '%{$remoteTag}%' THEN 1 END) AS remote_tasks
            FROM glpi_tickets t
            LEFT JOIN glpi_tickettasks tt ON tt.tickets_id = t.id
            WHERE t.is_deleted = 0
              {$typeFilter}
              AND t.entities_id IN ({$entities})
              AND t.date >= '{$fromSql}'
              AND t.date <= '{$toSql}'
        ";

        $result = $DB->query($sql);
        $row = $result ? $DB->fetchAssoc($result) : [];

        $resolved = self::resolvedCount($from, $to);
        $tagged = (int)($row['tagged_tickets'] ?? 0);
        $complete = (int)($row['rca_complete'] ?? 0);

        return [
            'ai_tagged'            => $tagged,
            'rca_complete'         => $complete,
            'remote_tasks'         => (int)($row['remote_tasks'] ?? 0),
            'rca_coverage_pct'     => $resolved > 0 ? round(($tagged / $resolved) * 100, 1) : 0.0,
            'rca_complete_pct'     => $resolved > 0 ? round(($complete / $resolved) * 100, 1) : 0.0,
            'resolved_for_rca_den' => $resolved,
        ];
    }

    private static function resolvedCount(DateTimeInterface $from, DateTimeInterface $to): int
    {
        global $DB;

        $fromSql = $DB->escape($from->format('Y-m-d H:i:s'));
        $toSql   = $DB->escape($to->format('Y-m-d H:i:s'));
        $entities = self::entitySql();
        $typeFilter = ((int)Settings::get('show_only_incidents', 1) === 1)
            ? ' AND t.`type` = ' . (int)Ticket::INCIDENT_TYPE
            : '';

        $sql = "
            SELECT COUNT(*) AS total
            FROM glpi_tickets t
            WHERE t.is_deleted = 0
              {$typeFilter}
              AND t.entities_id IN ({$entities})
              AND t.date >= '{$fromSql}'
              AND t.date <= '{$toSql}'
              AND t.status IN (" . (int)Ticket::SOLVED . ', ' . (int)Ticket::CLOSED . ")
        ";

        $result = $DB->query($sql);
        $row = $result ? $DB->fetchAssoc($result) : [];
        return (int)($row['total'] ?? 0);
    }

    private static function resolveMbtr(array $row): ?float
    {
        $source = (string)Settings::get('mbtr_source', 'none');
        $map = [
            'waiting_duration' => 'avg_waiting',
            'close_delay_stat' => 'avg_close_delay',
            'actiontime'       => 'avg_actiontime',
            'solve_delay_stat' => 'avg_solve_delay',
        ];

        if (!isset($map[$source])) {
            return null;
        }

        return self::floatOrNull($row[$map[$source]] ?? null);
    }

    public static function periodFromRequest(array $request): array
    {
        $defaultDays = max(1, (int)Settings::get('default_period_days', 30));
        $days = isset($request['days']) ? max(1, min(3650, (int)$request['days'])) : $defaultDays;

        $to = new DateTimeImmutable('now');
        $from = $to->modify('-' . ($days - 1) . ' days')->setTime(0, 0, 0);

        if (!empty($request['from']) && !empty($request['to'])) {
            $customFrom = DateTimeImmutable::createFromFormat('Y-m-d H:i:s', $request['from'] . ' 00:00:00');
            $customTo   = DateTimeImmutable::createFromFormat('Y-m-d H:i:s', $request['to'] . ' 23:59:59');
            if ($customFrom && $customTo && $customFrom <= $customTo) {
                $from = $customFrom;
                $to   = $customTo;
            }
        }

        return [$from, $to];
    }

    public static function duration(?float $seconds): string
    {
        if ($seconds === null) {
            return '—';
        }

        $seconds = max(0, (int)round($seconds));
        $days = intdiv($seconds, 86400);
        $hours = intdiv($seconds % 86400, 3600);
        $minutes = intdiv($seconds % 3600, 60);
        $secs = $seconds % 60;

        if ($days > 0) {
            return sprintf('%dd %02dh %02dm', $days, $hours, $minutes);
        }
        if ($hours > 0) {
            return sprintf('%dh %02dm', $hours, $minutes);
        }
        if ($minutes > 0) {
            return sprintf('%dm %02ds', $minutes, $secs);
        }
        return sprintf('%ds', $secs);
    }

    private static function entitySql(): string
    {
        $ids = $_SESSION['glpiactiveentities'] ?? [($_SESSION['glpiactive_entity'] ?? 0)];
        if (!is_array($ids) || $ids === []) {
            $ids = [0];
        }

        $ids = array_values(array_unique(array_map('intval', $ids)));
        return implode(',', $ids);
    }

    private static function floatOrNull(mixed $value): ?float
    {
        if ($value === null || $value === '') {
            return null;
        }
        return (float)$value;
    }
}
