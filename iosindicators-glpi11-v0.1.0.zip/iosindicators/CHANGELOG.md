# Changelog

## 0.1.0 - 2026-09-28

- Dashboard operacional de incidentes.
- Integração com o dashboard nativo do GLPI.
- TTO, TTS, MTTR, TMA e MBTR configurável.
- Indicadores de qualidade para IA/RCA.
- Etiquetas configuráveis para IA e atividade remota.
