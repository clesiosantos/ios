<?php

use GlpiPlugin\Iosindicators\Dashboard;
use GlpiPlugin\Iosindicators\Metrics;

include(__DIR__ . '/../../../inc/includes.php');

if (!Dashboard::canView()) {
    Html::displayErrorAndDie(__('Você precisa da permissão "Ver todos os tickets" para acessar os indicadores consolidados.', 'iosindicators'));
}

[$from, $to] = Metrics::periodFromRequest($_GET);
$summary = Metrics::summary($from, $to);

Html::header(
    __('Indicadores de Incidentes', 'iosindicators'),
    $_SERVER['PHP_SELF'],
    'plugins',
    Dashboard::class
);

echo '<div class="container-fluid py-3 iosindicators-wrapper">';
echo '<div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-3">';
echo '<div><h2 class="mb-1">Indicadores Operacionais de Incidentes</h2>';
echo '<div class="text-muted">Ciclo Zabbix → GLPI → Tratativa → Normalização → RCA / Base de Conhecimento</div></div>';

echo '<form method="get" class="d-flex flex-wrap align-items-end gap-2 iosindicators-filter">';
echo '<div><label class="form-label mb-1">Período rápido</label><select class="form-select" name="days">';
$currentDays = isset($_GET['days']) ? (int)$_GET['days'] : 30;
foreach ([1 => 'Hoje', 7 => '7 dias', 30 => '30 dias', 90 => '90 dias', 365 => '1 ano'] as $days => $label) {
    $selected = ($currentDays === $days && empty($_GET['from'])) ? ' selected' : '';
    echo '<option value="' . $days . '"' . $selected . '>' . htmlescape($label) . '</option>';
}
echo '</select></div>';
echo '<div><label class="form-label mb-1">De</label><input type="date" class="form-control" name="from" value="' . htmlescape((string)($_GET['from'] ?? '')) . '"></div>';
echo '<div><label class="form-label mb-1">Até</label><input type="date" class="form-control" name="to" value="' . htmlescape((string)($_GET['to'] ?? '')) . '"></div>';
echo '<button class="btn btn-primary" type="submit"><i class="ti ti-filter"></i> Aplicar</button>';
echo '</form></div>';

echo '<div class="alert alert-info py-2">Período considerado: <strong>' . $from->format('d/m/Y H:i') . '</strong> até <strong>' . $to->format('d/m/Y H:i') . '</strong>. O recorte usa a data de abertura do ticket.</div>';

Dashboard::renderPage($summary);

echo '</div>';
Html::footer();
