<?php

use Glpi\Plugin\Hooks;
use GlpiPlugin\Iosindicators\Dashboard;

/**
 * IOS Indicators - Indicadores operacionais para GLPI 11.
 */
define('PLUGIN_IOSINDICATORS_VERSION', '0.1.0');
define('PLUGIN_IOSINDICATORS_MIN_GLPI_VERSION', '11.0.0');
define('PLUGIN_IOSINDICATORS_MAX_GLPI_VERSION', '11.0.99');

function plugin_init_iosindicators(): void
{
    global $PLUGIN_HOOKS;

    $PLUGIN_HOOKS['csrf_compliant']['iosindicators'] = true;

    if (Session::getLoginUserID()) {
        // Menu principal do plugin. O próprio Dashboard restringe a visualização a perfis com READALL em tickets.
        if (Dashboard::canView()) {
            $PLUGIN_HOOKS[Hooks::MENU_TOADD]['iosindicators'] = [
                'plugins' => Dashboard::class,
            ];
        }

        // Página de configuração para administradores.
        if (Session::haveRight('config', UPDATE)) {
            $PLUGIN_HOOKS[Hooks::CONFIG_PAGE]['iosindicators'] = 'front/config.php';
        }

        $PLUGIN_HOOKS[Hooks::ADD_CSS]['iosindicators'] = 'css/iosindicators.css';
    }

    // Integração com o dashboard nativo do GLPI.
    $PLUGIN_HOOKS['dashboard_types']['iosindicators'] = [Dashboard::class, 'dashboardTypes'];
    $PLUGIN_HOOKS['dashboard_cards']['iosindicators'] = [Dashboard::class, 'dashboardCards'];
}

function plugin_version_iosindicators(): array
{
    return [
        'name'         => 'IOS - Indicadores de Incidentes',
        'version'      => PLUGIN_IOSINDICATORS_VERSION,
        'author'       => 'IOS',
        'license'      => 'GPLv3+',
        'homepage'     => '',
        'requirements' => [
            'glpi' => [
                'min' => PLUGIN_IOSINDICATORS_MIN_GLPI_VERSION,
                'max' => PLUGIN_IOSINDICATORS_MAX_GLPI_VERSION,
            ],
            'php' => [
                'min' => '8.2.0',
            ],
        ],
    ];
}

function plugin_iosindicators_check_prerequisites(): bool
{
    return version_compare(GLPI_VERSION, PLUGIN_IOSINDICATORS_MIN_GLPI_VERSION, '>=')
        && version_compare(GLPI_VERSION, PLUGIN_IOSINDICATORS_MAX_GLPI_VERSION, '<');
}

function plugin_iosindicators_check_config(bool $verbose = false): bool
{
    return true;
}
